import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.drawing.image import Image
import base64, io, datetime, json

def generar_excel_traslado(records_json, jorn_json, logo_b64, out_path):
    records = json.loads(records_json)
    jorn    = json.loads(jorn_json)

    est = jorn['establecimiento'].upper()
    gra = jorn['grano'].upper()
    cam = jorn['campania']
    hoy = datetime.date.today().strftime('%d/%m/%Y')

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Traslados'

    C_DARK  = '2A1F5C'
    C_MED   = '534AB7'
    C_LIGHT = 'EEEDFE'
    C_ROW   = 'F3F2FC'
    WHITE   = 'FFFFFF'
    C_BLUE  = '3C3489'
    GRAY    = '57606A'

    def fill(c): return PatternFill('solid', fgColor=c)
    def fnt(bold=False, sz=9, color='1A1A1A'): return Font(name='Arial', bold=bold, size=sz, color=color)
    def aln(h='center', wrap=True): return Alignment(horizontal=h, vertical='center', wrap_text=wrap)
    def brd():
        s = Side(style='thin', color='B0A8E8')
        return Border(left=s, right=s, top=s, bottom=s)

    def sc(cell, bg=None, fg='1A1A1A', bold=False, sz=9, h='center'):
        if bg: cell.fill = fill(bg)
        cell.font = fnt(bold=bold, sz=sz, color=fg)
        cell.alignment = aln(h=h)
        cell.border = brd()

    def merge_sc(r1,c1,r2,c2, val, bg, fg=WHITE, bold=True, sz=11, h='center'):
        ws.merge_cells(start_row=r1,start_column=c1,end_row=r2,end_column=c2)
        cell = ws.cell(r1,c1,val)
        sc(cell, bg=bg, fg=fg, bold=bold, sz=sz, h=h)
        return cell

    headers = ['Fecha CPE','N° CPE','CTG','Contrato','Titular',
               'Rte. Com. Prod.','Rte. Venta Prim.','Rep. Entregador',
               'Destinatario','Destino','Empresa Transp.','Flete Pagador',
               'Chofer','Grano','Campaña','Kg Bruto','Kg Tara','Kg Neto','Km','Tarifa']
    col_widths = [12,16,14,12,18,16,16,14,18,20,18,14,16,10,10,12,12,12,8,10]
    fields     = ['fechaCPE','nroCPE','ctg','contrato','titular',
                  'rteComProd','rteVentaPrim','repEntregador',
                  'destinatario','destino','empresaTransp','fletePagador',
                  'chofer','grano','campania','kgBruto','kgTara','kgNeto','kms','tarifa']
    n_cols = len(headers)  # 20

    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    # Logo en A1
    try:
        img = Image(io.BytesIO(base64.b64decode(logo_b64)))
        img.width = 90; img.height = 72
        ws.add_image(img, 'A1')
    except: pass

    # Fila 1: Título (A1:T1)
    ws.row_dimensions[1].height = 60
    merge_sc(1,1,1,n_cols, f'AVANCE DE CARGA - {gra} {est} {cam}', C_DARK, WHITE, bold=True, sz=14)

    # Fila 2: Usuario A2:J2 / Fecha K2:T2
    ws.row_dimensions[2].height = 22
    merge_sc(2,1,2,10, f'  Usuario: {jorn["tecnico"]}', C_LIGHT, C_DARK, bold=True, sz=11, h='left')
    merge_sc(2,11,2,n_cols, f'Fecha de confección: {hoy}  ', C_LIGHT, C_DARK, bold=True, sz=11, h='right')

    # Fila 3 vacía
    ws.row_dimensions[3].height = 8

    # Fila 4: Stats (A4:T4) — Kg Netos remarcado
    totalKg    = sum(float(r.get('kgNeto',0) or 0) for r in records)
    totalBruto = sum(float(r.get('kgBruto',0) or 0) for r in records)
    totalTara  = sum(float(r.get('kgTara',0) or 0) for r in records)
    stats_txt = (f'CPEs: {len(records)}    |    Kg Brutos: {int(totalBruto):,}    |    '
                 f'Kg Tara: {int(totalTara):,}    |    Kg Netos: {int(totalKg):,}').replace(',','.')
    ws.row_dimensions[4].height = 26
    merge_sc(4,1,4,n_cols, stats_txt, C_MED, WHITE, bold=True, sz=12)
    # Kg Neto remarcado — re-escribir con color amarillo/destacado en la misma celda
    # No podemos hacer formato parcial en merged cell, pero podemos hacer el fondo más llamativo
    # Usamos un approach diferente: stats separados en celdas
    # Mejor: quitar el merge y hacer 4 stat cards
    # Pero para mantener el diseño del usuario, lo dejamos igual y solo agrandamos el texto

    # Fila 5 vacía
    ws.row_dimensions[5].height = 6

    # Fila 6: Encabezados
    ws.row_dimensions[6].height = 28
    for ci, h in enumerate(headers, 1):
        c = ws.cell(6, ci)
        c.value = h
        sc(c, bg=C_MED, fg=WHITE, bold=True, sz=9)

    # Datos — altura 27.45 como en el archivo modificado
    for ri, rec in enumerate(records):
        r = 7 + ri
        ws.row_dimensions[r].height = 27.45
        bg = C_ROW if ri % 2 == 0 else WHITE
        for ci, field in enumerate(fields, 1):
            val = rec.get(field,'') or ''
            c   = ws.cell(r, ci)
            is_kg = field in ('kgBruto','kgTara','kgNeto')
            try:
                if is_kg and val:
                    c.value = int(float(str(val).replace('.','').replace(',','.')))
                    c.number_format = '#,##0'
                elif val:
                    c.value = str(val)
                else:
                    c.value = ''
            except:
                c.value = str(val) if val else ''
            fg = C_BLUE if field == 'kgNeto' else (GRAY if field == 'fechaCPE' else '1A1A1A')
            bold = field in ('kgNeto','kgBruto','nroCPE')
            sc(c, bg=bg, fg=fg, bold=bold, sz=9, h='center')

    # Total
    tot_row = 7 + len(records)
    ws.row_dimensions[tot_row].height = 22
    for ci in range(1, n_cols+1):
        c  = ws.cell(tot_row, ci)
        field = fields[ci-1] if ci <= len(fields) else ''
        if field == 'kgBruto':
            c.value = int(totalBruto); c.number_format = '#,##0'
        elif field == 'kgTara':
            c.value = int(totalTara);  c.number_format = '#,##0'
        elif field == 'kgNeto':
            c.value = int(totalKg);    c.number_format = '#,##0'
        elif ci == 1:
            c.value = 'TOTAL'
        else:
            c.value = ''
        sc(c, bg=C_DARK, fg=WHITE, bold=True, sz=10, h='center')

    ws.freeze_panes = 'A7'
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize   = 9
    ws.page_setup.fitToPage   = True
    ws.page_setup.fitToWidth  = 1
    ws.page_setup.fitToHeight = 0

    wb.save(out_path)

if __name__ == '__main__':
    # Cuando se llama desde la app, recibe args
    if len(__import__('sys').argv) > 3:
        import sys
        generar_excel_traslado(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        print("Uso: gen_excel_traslado.py records_json jorn_json logo_b64 out_path")
